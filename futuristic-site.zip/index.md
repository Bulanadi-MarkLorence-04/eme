---
layout: default
title: Home
---

# 🌌 Welcome to Futuristic Blue
This is my **sci-fi inspired site** with neon blue accents 🚀
